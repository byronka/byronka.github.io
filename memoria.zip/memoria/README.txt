Memoria v1.0.0
==============

A family tree website.


You need Java 21 or greater installed for this to run.


to test that you have the proper version of Java:

    $ java -version
    java version "21.0.7" 2025-04-15 LTS


The default privacy password is set in memoria.config. The initial password
is "dad" - you will find it listed in the configuration file like this:

    PRIVACY_PASSWORD=dad


to run, type the following in a terminal and press enter:

    java -jar inmra.jar

(When it's fully loaded, visit http://localhost:8080 or https://localhost:8443)


The first time this runs, it will create an admin password in this same
directory, in a file called "admin_password".  Copy that password, and use
a username of "admin", to login with the administrator account, at:

    http://localhost:8080/login

Once logged in as administrator, you may create new user accounts by
registering them from the menu in the UI.

to stop the application, in the terminal where you had started the
application, press the "ctrl + c" buttons. 

The first time this runs, it will create a database in this same directory,
in a folder called "db".

Configuration of the application is controlled by the two 
files "minum.config" and "memoria.config"
