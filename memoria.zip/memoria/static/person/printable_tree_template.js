"use strict";

class PrintableTreeTemplate {

    /**
      * The count of columns for showing the summary at the top,
      * set by a select input.
      */
    summaryColumnCount;

    /**
      * The count of columns for showing the details at the bottom,
      * set by a select input.
      */
    detailsColumnCount;

    /**
      * The summary section, which has its style modified by the code
      */
    summarySection;

    /**
      * The section for details of each person in the family tree
      */
    detailsSection;

    constructor() {
        this.summaryColumnCount = document.getElementById('summary_column_count');
        this.detailsColumnCount = document.getElementById('details_column_count');
        this.summarySection = document.getElementById('summary');
        this.detailsSection = document.getElementById('details');
    }

    addEvents = () => {
        this.summaryColumnCount.addEventListener("change", this.summaryColumnCountChangeHandler);
        this.detailsColumnCount.addEventListener("change", this.detailsColumnCountChangeHandler);
    }

    summaryColumnCountChangeHandler = (event) => {
        const newValue = event.target.value;
        this.summarySection.style.columns = newValue;
    }

    detailsColumnCountChangeHandler = (event) => {
        const newValue = event.target.value;
        this.detailsSection.style.columns = newValue;
    }

}

// run the code after the page is fully loaded
addEventListener("load", (event) => {
    const printableTreeTemplate = new PrintableTreeTemplate();
    printableTreeTemplate.addEvents();
});